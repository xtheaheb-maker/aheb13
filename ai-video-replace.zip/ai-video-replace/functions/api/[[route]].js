// نظام المعالجة (Backend): وسيط آمن بين الواجهة وخدمة fal.ai — مفتاح الـ API لا يصل للمتصفح أبداً.
// لتبديل المزوّد لاحقاً: عدّل هذا الملف فقط، الواجهة لا تتغير.
const PERSON_MODEL = "fal-ai/wan/v2.2-14b/animate/replace";

const json = (d, s = 200) =>
  new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json" } });

// عدّل هنا مدخلات كل نموذج إذا غيّرت النموذج (راجع صفحة API الخاصة به في fal.ai)
function buildInput(mode, b) {
  if (mode === "person")
    return { video_url: b.video_url, image_url: b.image_url, resolution: b.resolution || "720p" };
  return { video_url: b.video_url, image_url: b.image_url, image_urls: [b.image_url], prompt: b.prompt || "" };
}

const isHttps = (u) => { try { return new URL(u).protocol === "https:"; } catch { return false; } };

export async function onRequest({ request, env, params }) {
  if (!env.FAL_KEY) return json({ error: "FAL_KEY غير مضبوط في إعدادات Cloudflare." }, 500);
  const route = [].concat(params.route || []).join("/");
  const headers = { Authorization: `Key ${env.FAL_KEY}`, "Content-Type": "application/json" };

  try {
    if (route === "upload-init" && request.method === "POST") {
      const { content_type, file_name } = await request.json();
      const r = await fetch("https://rest.alpha.fal.ai/storage/upload/initiate?storage_type=fal-cdn-v3", {
        method: "POST", headers, body: JSON.stringify({ content_type, file_name }),
      });
      if (!r.ok) return json({ error: "فشل تجهيز الرفع", detail: await r.text() }, 502);
      const d = await r.json();
      return json({ upload_url: d.upload_url, file_url: d.file_url });
    }

    if (route === "submit" && request.method === "POST") {
      const b = await request.json();
      const model = b.mode === "person" ? PERSON_MODEL : env.FAL_OBJECT_MODEL;
      if (!model) return json({ error: "استبدال العناصر/السيارات يحتاج ضبط FAL_OBJECT_MODEL (انظر README)." }, 501);
      if (!isHttps(b.video_url) || !isHttps(b.image_url)) return json({ error: "روابط الملفات غير صالحة" }, 400);
      const r = await fetch(`https://queue.fal.run/${model}`, {
        method: "POST", headers, body: JSON.stringify(buildInput(b.mode, b)),
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) return json({ error: "رفضت الخدمة الطلب", detail: d }, 502);
      return json({ request_id: d.request_id, status_url: d.status_url, response_url: d.response_url });
    }

    if (route === "status" && request.method === "GET") {
      const q = new URL(request.url).searchParams;
      const su = q.get("status_url"), ru = q.get("response_url");
      for (const u of [su, ru]) if (!u || new URL(u).hostname !== "queue.fal.run") return json({ error: "رابط غير مسموح" }, 400);
      const s = await (await fetch(su, { headers })).json();
      if (s.status !== "COMPLETED") return json({ status: s.status, queue_position: s.queue_position ?? null });
      const res = await fetch(ru, { headers });
      const d = await res.json().catch(() => ({}));
      const url = d.video && d.video.url;
      if (!res.ok || !url) return json({ status: "FAILED", error: "انتهت المعالجة بدون فيديو ناتج", detail: d });
      return json({ status: "COMPLETED", video_url: url });
    }
    return json({ error: "مسار غير موجود" }, 404);
  } catch (e) {
    return json({ error: "خطأ داخلي", detail: String(e) }, 500);
  }
}
