# AI Video Replace

واجهة (public/) + وسيط معالجة (functions/api/) يعمل على Cloudflare Pages Functions.

## الخدمة المطلوبة (تحتاج API Key)
- **fal.ai** — أنشئ مفتاحاً من fal.ai/dashboard/keys (مدفوع بالاستخدام، يلزم رصيد).
- النموذج المستخدم لاستبدال الأشخاص: `fal-ai/wan/v2.2-14b/animate/replace` (Wan 2.2 Animate، وضع Replace).

## التشغيل محلياً
```
cp .dev.vars.example .dev.vars   # ضع FAL_KEY
npx wrangler pages dev public
```

## النشر على Cloudflare Pages
```
npx wrangler pages deploy public
```
ثم من Settings → Variables and Secrets أضف **FAL_KEY** كـ Secret.
(مجلد functions يجب أن يكون في جذر المشروع كما هو.)

## حدود يجب معرفتها
1. **الأشخاص**: النموذج يستبدل الشخص الرئيسي في المشهد؛ لا يوجد اختيار يدوي لشخص بعينه عند وجود عدة أشخاص.
2. **السيارات والعناصر**: نموذج Wan Animate مخصص للشخصيات فقط. لتفعيل الاستبدال العام اختر نموذج تعديل فيديو يدعم صورة مرجعية من fal.ai، ضع معرّفه في متغير `FAL_OBJECT_MODEL`، وعدّل دالة `buildInput` في `functions/api/[[route]].js` حسب مدخلاته. الإعداد الحالي لم أختبره على نموذج محدد.
3. **الصوت**: الناتج قد لا يحتوي الصوت الأصلي. لدمجه محلياً:
```
ffmpeg -i result.mp4 -i original.mp4 -map 0:v -map 1:a? -c:v copy -c:a aac -shortest final.mp4
```
دمج الصوت تلقائياً داخل الموقع يحتاج خدمة خادمية (مثل Cloudflare Containers) — مرحلة تطوير لاحقة.
4. **الجودة**: الدقة القصوى 720p تقريباً، والمقاطع القصيرة تعطي أفضل نتيجة. الإضاءة والظلال والمنظور يتعامل معها النموذج ولا توجد ضمانات.
5. نقطة رفع الملفات (`rest.alpha.fal.ai/storage/upload/initiate`) هي التي يستخدمها عميل fal الرسمي، لكنها لم تُختبر هنا؛ جرّبها أول مرة بمقطع صغير.
6. تأكد من امتلاك حقوق الفيديو والصورة وموافقة الأشخاص الظاهرين فيهما.
